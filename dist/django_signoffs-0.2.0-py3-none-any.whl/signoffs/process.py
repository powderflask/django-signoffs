"""
    Proxy for Approval Process to simplify import statements
"""

from signoffs.core.process import (
    ApprovalsProcess,
    FsmApprovalsProcess,
)
